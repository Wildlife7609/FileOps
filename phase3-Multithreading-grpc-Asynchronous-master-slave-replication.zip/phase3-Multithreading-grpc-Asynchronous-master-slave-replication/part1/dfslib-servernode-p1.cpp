#include "dfslib-servernode-p1.h"

#include <dirent.h>
#include <errno.h>
#include <getopt.h>
#include <grpcpp/grpcpp.h>
#include <sys/stat.h>

#include <chrono>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <thread>

#include "dfslib-shared-p1.h"
#include "proto-src/dfs-service.grpc.pb.h"
#include "src/dfs-utils.h"

using grpc::Server;
using grpc::ServerBuilder;
using grpc::ServerContext;
using grpc::ServerReader;
using grpc::ServerWriter;
using grpc::Status;
using grpc::StatusCode;

using dfs_service::DFSService;

//
// STUDENT INSTRUCTION:
//
// DFSServiceImpl is the implementation service for the rpc methods
// and message types you defined in the `dfs-service.proto` file.
//
// You should add your definition overrides here for the specific
// methods that you created for your GRPC service protocol. The
// gRPC tutorial described in the readme is a good place to get started
// when trying to understand how to implement this class.
//
// The method signatures generated can be found in
// `proto-src/dfs-service.grpc.pb.h` file.
//
// Look for the following section:
//
//      class Service : public ::grpc::Service {
//
// The methods returning grpc::Status are the methods you'll want to override.
//
// In C++, you'll want to use the `override` directive as well. For example,
// if you have a service method named MyMethod that takes a MyMessageType
// and a ServerWriter, you'll want to override it similar to the following:
//
//      Status MyMethod(ServerContext* context,
//                      const MyMessageType* request,
//                      ServerWriter<MySegmentType> *writer) override {
//
//          /** code implementation here **/
//      }
//
class DFSServiceImpl final : public DFSService::Service {
 private:
  /** The mount path for the server **/
  std::string mount_path;

  /**
   * Prepend the mount path to the filename.
   *
   * @param filepath
   * @return
   */
  const std::string WrapPath(const std::string& filepath) {
    return this->mount_path + filepath;
  }

 public:
  DFSServiceImpl(const std::string& mount_path) : mount_path(mount_path) {}

  ~DFSServiceImpl() {}

  //
  // STUDENT INSTRUCTION:
  //
  // Add your additional code here, including
  // implementations of your protocol service methods

  grpc::Status storeFile(
      grpc::ServerContext* context,
      grpc::ServerReader< ::dfs_service::StoreRequest>* reader,
      dfs_service::StoreReply* response) override {
    // store request message type
    StoreRequest request;
    // get the metadata
    auto metadata = context->client_metadata();
    std::string filename =
        std::string(metadata.find("filename")->second.data(),
                    metadata.find("filename")->second.length());
    std::string file_size =
        std::string(metadata.find("filesize")->second.data(),
                    metadata.find("filesize")->second.length());
    dfs_log(LL_SYSINFO) << "filename: " << filename;
    dfs_log(LL_SYSINFO) << "filesize: " << file_size;
    if (filename.empty() || file_size.empty()) {
      return grpc::Status(StatusCode::CANCELLED,
                          "Filename or filesize is empty");
    }
    int file_size_int = std::stoi(file_size);
    const std::string& wrapped_path = WrapPath(filename);
    // handle error
    try {
      // operator the file to receive the file content
      std::ofstream file_stream(wrapped_path);
      if (!file_stream.is_open()) {
        return grpc::Status(StatusCode::CANCELLED, "File cannot be opened");
      }
      int bytes_read = 0;
      // read the file content and write to the file, while Read() returns true
      // which means the file is not end
      while (reader->Read(&request)) {
        // check the deadline before write the file
        if (context->IsCancelled()) {
          dfs_log(LL_SYSINFO) << "Deadline exceeded\n";
          return grpc::Status(StatusCode::DEADLINE_EXCEEDED,
                              "Deadline exceeded");
        }
        file_stream.write(request.filecontent().c_str(),
                          request.filecontent().length());
        bytes_read += request.filecontent().length();
        dfs_log(LL_SYSINFO)
            << "write the file:-->" << wrapped_path << "bytes_read:-->"
            << request.filecontent().length() << "\n";
      }
      file_stream.close();
      if (file_size_int != bytes_read) {
        dfs_log(LL_SYSINFO) << "file:-->" << wrapped_path
                            << "is not match the client file size\n";
        return grpc::Status(StatusCode::CANCELLED, "File size mismatched");
      }
    } catch (std::exception& e) {
      dfs_log(LL_SYSINFO) << "storeFile exception\n";
      return grpc::Status(StatusCode::CANCELLED, "storeFile exception");
    }
    struct stat buf;
    if (stat(wrapped_path.c_str(), &buf) != 0) {
      dfs_log(LL_SYSINFO) << "file:-->" << wrapped_path << "is not found\n";
      return grpc::Status(StatusCode::NOT_FOUND, "file not found");
    }
    int modified_time = buf.st_mtime;

    dfs_log(LL_SYSINFO) << "file:-->" << wrapped_path
                        << "is stored successfully\n";
    response->set_filename(filename);
    response->set_modifiedtime(modified_time);
    return grpc::Status::OK;
  }

  grpc::Status fetchFile(
      grpc::ServerContext* context, const dfs_service::FetchRequest* request,
      grpc::ServerWriter< ::dfs_service::StoreRequest>* writer) override {
    // fetch reply message type
    StoreRequest reply;
    // get the file name
    string filename = request->filename();
    const std::string& wrapped_path = WrapPath(filename);
    dfs_log(LL_SYSINFO) << "get the file path:-->" << wrapped_path << "\n";
    struct stat buf;
    // check the file existence
    if (stat(wrapped_path.c_str(), &buf) != 0) {
      dfs_log(LL_SYSINFO) << "file:-->" << wrapped_path << "is not found\n";
      return grpc::Status(StatusCode::NOT_FOUND, "file not found");
    }
    int file_size = buf.st_size;
    dfs_log(LL_SYSINFO) << "size:-->" << file_size << "\n";
    // handle error
    try {
      // get the file size and open the file
      std::ifstream file_strean(wrapped_path);
      if (!file_strean.is_open()) {
        dfs_log(LL_SYSINFO)
            << "file:-->" << wrapped_path << "cannot be opened\n";
        return grpc::Status(StatusCode::CANCELLED, "cannot be opened");
      }
      int bytes_read = 0;
      // read and write the file
      while (file_size > 0) {
        // check the deadline before read the file
        if (context->IsCancelled()) {
          dfs_log(LL_SYSINFO) << "Deadline exceeded\n";
          return grpc::Status(StatusCode::DEADLINE_EXCEEDED,
                              "Mismatched status code");
        }
        char* buffer = new char[DFS_BLOCK_SIZE];
        memset(buffer, 0, DFS_BLOCK_SIZE);
        bytes_read = std::min(file_size, DFS_BLOCK_SIZE);
        file_strean.read(buffer, bytes_read);
        file_size -= bytes_read;
        reply.set_filecontent(buffer, bytes_read);
        writer->Write(reply);
        dfs_log(LL_SYSINFO) << "write the file:-->" << filename
                            << "bytes_read:-->" << bytes_read << "\n";
        delete[] buffer;
      }
      file_strean.close();
      // add the metadata filesize
      context->AddInitialMetadata("filesize", std::to_string(file_size));
    } catch (std::exception& e) {
      dfs_log(LL_SYSINFO) << "fetchFile exception\n";
      return grpc::Status(StatusCode::CANCELLED, "fetchFile exception");
    }
    if (context->IsCancelled()) {
      dfs_log(LL_SYSINFO) << "Deadline exceeded\n";
      return grpc::Status(StatusCode::DEADLINE_EXCEEDED,
                          "Mismatched status code");
    }
    dfs_log(LL_SYSINFO) << "file:-->" << filename
                        << "is fetched successfully\n";
    return grpc::Status::OK;
  }

  grpc::Status deleteFile(grpc::ServerContext* context,
                          const dfs_service::FetchRequest* request,
                          dfs_service::Empty* response) override {
    // Implement deleteFile logic here
    if (context->IsCancelled()) {
      return grpc::Status(StatusCode::DEADLINE_EXCEEDED,
                          "Mismatched status code");
    }
    const std::string& wrapped_path = WrapPath(request->filename());
    struct stat buffer;
    if (stat(wrapped_path.c_str(), &buffer) != 0) {
      return grpc::Status(StatusCode::NOT_FOUND, "Mismatched status code");
    }
    // check the file existence
    if (remove(wrapped_path.c_str()) != 0) {
      return grpc::Status(StatusCode::CANCELLED, "Mismatched status code");
    }
    return grpc::Status::OK;
  }

  grpc::Status listFiles(grpc::ServerContext* context,
                         const dfs_service::Empty* request,
                         dfs_service::ListReply* response) override {
    // Implement listFiles logic here reference:
    // https://stackoverflow.com/questions/612097/how-can-i-get-the-list-of-files-in-a-directory-using-c-or-c
    // since my cpp version is 9, I cannot use std::filesystem
    DIR* dir;
    struct dirent* ent;
    // check the directory
    if ((dir = opendir(this->mount_path.c_str())) != NULL) {
      while ((ent = readdir(dir)) != NULL) {
        if (context->IsCancelled()) {
          dfs_log(LL_SYSINFO) << "Deadline exceeded, context is cancelled\n";
          return grpc::Status(StatusCode::DEADLINE_EXCEEDED,
                              "Mismatched status code");
        }
        // check the file type
        if (ent->d_type == DT_REG) {
          StoreReply* file = response->add_files();
          file->set_filename(ent->d_name);
          struct stat buf;
          const std::string& wrapped_path = WrapPath(ent->d_name);
          if (stat(wrapped_path.c_str(), &buf) != 0) {
            dfs_log(LL_SYSINFO) << "file:-->" << wrapped_path
                                << "is not found, path is not right warning!\n";
            return grpc::Status(StatusCode::NOT_FOUND,
                                "Mismatched status code");
          }
          file->set_modifiedtime(buf.st_mtime);
        }
      }
      closedir(dir);
    } else {
      return grpc::Status(StatusCode::CANCELLED, "Mismatched status code");
    }
    return grpc::Status::OK;
  }

  grpc::Status statusOfFile(grpc::ServerContext* context,
                            const dfs_service::FetchRequest* request,
                            dfs_service::StatusOfReply* response) override {
    // Implement statusOfFile logic here
    if (context->IsCancelled()) {
      return grpc::Status(StatusCode::DEADLINE_EXCEEDED,
                          "Mismatched status code");
    }
    struct stat file_attr;
    const std::string& wrapped_path = WrapPath(request->filename());
    if (stat(wrapped_path.c_str(), &file_attr) != 0) {
      return grpc::Status(StatusCode::NOT_FOUND, "Mismatched status code");
    }
    response->set_size(file_attr.st_size);
    response->set_creationtime(file_attr.st_ctime);
    response->set_modifiedtime(file_attr.st_mtime);
    return grpc::Status::OK;
  }
};

//
// STUDENT INSTRUCTION:
//
// The following three methods are part of the basic DFSServerNode
// structure. You may add additional methods or change these slightly,
// but be aware that the testing environment is expecting these three
// methods as-is.
//
/**
 * The main server node constructor
 *
 * @param server_address
 * @param mount_path
 */
DFSServerNode::DFSServerNode(const std::string& server_address,
                             const std::string& mount_path,
                             std::function<void()> callback)
    : server_address(server_address),
      mount_path(mount_path),
      grader_callback(callback) {}

/**
 * Server shutdown
 */
DFSServerNode::~DFSServerNode() noexcept {
  dfs_log(LL_SYSINFO) << "DFSServerNode shutting down";
  this->server->Shutdown();
}

/** Server start **/
void DFSServerNode::Start() {
  DFSServiceImpl service(this->mount_path);
  ServerBuilder builder;
  builder.AddListeningPort(this->server_address,
                           grpc::InsecureServerCredentials());
  builder.RegisterService(&service);
  this->server = builder.BuildAndStart();
  dfs_log(LL_SYSINFO) << "DFSServerNode server listening on "
                      << this->server_address;
  this->server->Wait();
}

//
// STUDENT INSTRUCTION:
//
// Add your additional DFSServerNode definitions here
//