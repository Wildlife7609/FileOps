#include "dfslib-clientnode-p1.h"

#include <errno.h>
#include <getopt.h>
#include <grpcpp/grpcpp.h>
#include <limits.h>
#include <sys/inotify.h>
#include <unistd.h>

#include <chrono>
#include <csignal>
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <regex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include "dfslib-shared-p1.h"
#include "proto-src/dfs-service.grpc.pb.h"

using grpc::Channel;
using grpc::ClientContext;
using grpc::ClientReader;
using grpc::ClientWriter;
using grpc::Status;
using grpc::StatusCode;

//
// STUDENT INSTRUCTION:
//
// You may want to add aliases to your namespaced service methods here.
// All of the methods will be under the `dfs_service` namespace.
//
// For example, if you have a method named MyMethod, add
// the following:
//
//      using dfs_service::MyMethod
//

DFSClientNodeP1::DFSClientNodeP1() : DFSClientNode() {}

DFSClientNodeP1::~DFSClientNodeP1() noexcept {}

StatusCode DFSClientNodeP1::Store(const std::string &filename) {
  //
  // STUDENT INSTRUCTION:
  //
  // Add your request to store a file here. This method should
  // connect to your gRPC service implementation method
  // that can accept and store a file.
  //
  // When working with files in gRPC you'll need to stream
  // the file contents, so consider the use of gRPC's ClientWriter.
  //
  // The StatusCode response should be:
  //
  // StatusCode::OK - if all went well
  // StatusCode::DEADLINE_EXCEEDED - if the deadline timeout occurs
  // StatusCode::NOT_FOUND - if the file cannot be found on the client
  // StatusCode::CANCELLED otherwise

  // storeFile message type
  StoreRequest request;
  StoreReply reply;

  // open the file on the client, then get stat of the file
  struct stat buf;
  const string &wrapped_path = WrapPath(filename);
  if (stat(wrapped_path.c_str(), &buf) < 0) {
    dfs_log(LL_ERROR) << "stat error: client doesn't has this file -->"
                      << strerror(errno) << "\n";
    return StatusCode::NOT_FOUND;
  }
  int file_size = buf.st_size;
  dfs_log(LL_SYSINFO) << "get the file size:-->" << file_size << "\n";
  // set metadata and deadline in client context
  ClientContext context;
  context.AddMetadata("filename", filename);
  context.AddMetadata("filesize", std::to_string(file_size));
  context.set_deadline(std::chrono::system_clock::now() +
                       std::chrono::milliseconds(deadline_timeout));
  // get the client writer to write the file
  auto writer(service_stub->storeFile(&context, &reply));
  dfs_log(LL_SYSINFO) << "get the writer:-->" << wrapped_path << "\n";
  // handle exception, reference:
  // https://en.cppreference.com/w/cpp/io/basic_ios/exceptions
  try {
    // operate the file
    std::ifstream file_stream(wrapped_path);
    dfs_log(LL_SYSINFO) << "get the file stream:-->" << wrapped_path << "\n";
    if (!file_stream.is_open()) {
      dfs_log(LL_ERROR) << "open file error: " << strerror(errno) << "\n";
      return StatusCode::NOT_FOUND;
    }
    int bytes_read = 0;
    // read and write the file
    while (file_size > 0) {
      char *buffer = new char[DFS_BLOCK_SIZE];
      memset(buffer, 0, DFS_BLOCK_SIZE);
      bytes_read = std::min(file_size, DFS_BLOCK_SIZE);
      file_stream.read(buffer, bytes_read);
      file_size -= bytes_read;
      request.set_filecontent(buffer, bytes_read);
      if (!writer->Write(request)) {
        dfs_log(LL_ERROR) << "write file error: in write request -->"
                          << strerror(errno) << "\n";
        return StatusCode::CANCELLED;
      }
      dfs_log(LL_SYSINFO) << "write the file:-->" << wrapped_path
                          << "bytes_read:-->" << bytes_read << "\n";
      delete[] buffer;
    }
    // clean up
    file_stream.close();
  } catch (const std::exception &e) {
    dfs_log(LL_ERROR) << "store file error: ifstream inside -->" << e.what()
                      << "\n";
    return StatusCode::CANCELLED;
  }
  writer->WritesDone();
  // get server status
  Status status = writer->Finish();
  if (!status.ok()) {
    dfs_log(LL_ERROR) << "store file error: " << status.error_message() << "\n";
    return StatusCode::CANCELLED;
  }
  if (status.error_code() == StatusCode::DEADLINE_EXCEEDED) {
      dfs_log(LL_ERROR) << "fetch deadline error: " << status.error_message()
                        << "\n";
      return StatusCode::DEADLINE_EXCEEDED;
    }
  dfs_log(LL_SYSINFO) << "store file successfully: " << wrapped_path << "\n";
  return StatusCode::OK;
}

StatusCode DFSClientNodeP1::Fetch(const std::string &filename) {
  //
  // STUDENT INSTRUCTION:
  //
  // Add your request to fetch a file here. This method should
  // connect to your gRPC service implementation method
  // that can accept a file request and return the contents
  // of a file from the service.
  //
  // As with the store function, you'll need to stream the
  // contents, so consider the use of gRPC's ClientReader.
  //
  // The StatusCode response should be:
  //
  // StatusCode::OK - if all went well
  // StatusCode::DEADLINE_EXCEEDED - if the deadline timeout occurs
  // StatusCode::NOT_FOUND - if the file cannot be found on the server
  // StatusCode::CANCELLED otherwise

  // fetchFile message type
  FetchRequest request;
  StoreRequest reply;
  // set deadline in client context
  ClientContext context;
  context.set_deadline(std::chrono::system_clock::now() +
                       std::chrono::milliseconds(deadline_timeout));
  // send the request to server and ready to read the reply
  request.set_filename(filename);
  auto reader(service_stub->fetchFile(&context, request));
  dfs_log(LL_SYSINFO) << "get the reader:-->" << filename << "\n";
  // handle exception
  try {
    // operate the file to receive the content
    const string &wrapped_path = WrapPath(filename);
    std::ofstream file_stream(wrapped_path);
    if (!file_stream.is_open()) {
      dfs_log(LL_ERROR) << "open file error: " << strerror(errno) << "\n";
      return StatusCode::CANCELLED;
    }
    int bytes_read = 0;
    while (reader->Read(&reply)) {
      file_stream.write(reply.filecontent().c_str(),
                        reply.filecontent().size());
      bytes_read += reply.filecontent().size();
      dfs_log(LL_SYSINFO) << "write the file:-->" << filename
                          << "bytes_read:-->" << reply.filecontent().size()
                          << "\n";
    }
    // check the file size
    auto metadata_iterator =
        context.GetServerInitialMetadata().find("filesize");
    if (metadata_iterator != context.GetServerInitialMetadata().end()) {
      std::string filesize_str = metadata_iterator->second.data();
      int filesize = std::stoi(filesize_str);
      if (bytes_read != filesize) {
        dfs_log(LL_ERROR) << "fetch file error111: " << strerror(errno) << "\n";
        return StatusCode::CANCELLED;
      }
    }
    // clean up
    file_stream.close();
  } catch (const std::exception &e) {
    dfs_log(LL_ERROR) << "fetch file error222: " << e.what() << "\n";
    return StatusCode::CANCELLED;
  }
  // get server status
  Status status = reader->Finish();
  if (!status.ok()) {
    if (status.error_code() == StatusCode::NOT_FOUND) {
      dfs_log(LL_ERROR) << "fetch not found file error: "
                        << status.error_message() << "\n";
      return StatusCode::NOT_FOUND;
    }
    if (status.error_code() == StatusCode::DEADLINE_EXCEEDED) {
      dfs_log(LL_ERROR) << "fetch deadline error: " << status.error_message()
                        << "\n";
      return StatusCode::DEADLINE_EXCEEDED;
    }
    dfs_log(LL_ERROR) << "fetch cancelled file error: "
                      << status.error_message() << "\n";
    return StatusCode::CANCELLED;
  }
  dfs_log(LL_SYSINFO) << "fetch file successfully: " << filename << "\n";
  return StatusCode::OK;
}

StatusCode DFSClientNodeP1::Delete(const std::string &filename) {
  //
  // STUDENT INSTRUCTION:
  //
  // Add your request to delete a file here. Refer to the Part 1
  // student instruction for details on the basics.
  //
  // The StatusCode response should be:
  //
  // StatusCode::OK - if all went well
  // StatusCode::DEADLINE_EXCEEDED - if the deadline timeout occurs
  // StatusCode::NOT_FOUND - if the file cannot be found on the server
  // StatusCode::CANCELLED otherwise
  //
  // deleteFile message type
  FetchRequest request;
  Empty reply;
  // set deadline in client context and send the request to server, get the
  // server status
  ClientContext context;
  context.set_deadline(std::chrono::system_clock::now() +
                       std::chrono::milliseconds(deadline_timeout));
  request.set_filename(filename);
  Status status = service_stub->deleteFile(&context, request, &reply);
  // handle the server status
  if (!status.ok()) {
    if (status.error_code() == StatusCode::NOT_FOUND) {
      dfs_log(LL_ERROR) << "delete not found file error: "
                        << status.error_message() << "\n";
      return StatusCode::NOT_FOUND;
    }
    if (status.error_code() == StatusCode::DEADLINE_EXCEEDED) {
      dfs_log(LL_ERROR) << "delete deadline error: " << status.error_message()
                        << "\n";
      return StatusCode::DEADLINE_EXCEEDED;
    }
    dfs_log(LL_ERROR) << "delete cancelled file error: "
                      << status.error_message() << "\n";
    return StatusCode::CANCELLED;
  }
  dfs_log(LL_SYSINFO) << "delete file successfully: " << filename << "\n";
  return StatusCode::OK;
}

StatusCode DFSClientNodeP1::List(std::map<std::string, int> *file_map,
                                 bool display) {
  //
  // STUDENT INSTRUCTION:
  //
  // Add your request to list all files here. This method
  // should connect to your service's list method and return
  // a list of files using the message type you created.
  //
  // The file_map parameter is a simple map of files. You should fill
  // the file_map with the list of files you receive with keys as the
  // file name and values as the modified time (mtime) of the file
  // received from the server.
  //
  // The StatusCode response should be:
  //
  // StatusCode::OK - if all went well
  // StatusCode::DEADLINE_EXCEEDED - if the deadline timeout occurs
  // StatusCode::CANCELLED otherwise
  //
  // listFiles message type
  Empty request;
  ListReply reply;
  // set deadline in client context and send the request to server, get the
  // server status
  ClientContext context;
  context.set_deadline(std::chrono::system_clock::now() +
                       std::chrono::milliseconds(deadline_timeout));
  Status status = service_stub->listFiles(&context, request, &reply);
  // handle the server status
  if (!status.ok()) {
    if(status.error_code() == StatusCode::DEADLINE_EXCEEDED){
      return StatusCode::DEADLINE_EXCEEDED;
    }
    dfs_log(LL_ERROR) << "list file error: " << status.error_message() << "\n";
    return StatusCode::CANCELLED;
  }
  // file attribute use storeReply message type, reference: https://stackoverflow.com/questions/612097/how-can-i-get-the-list-of-files-in-a-directory-using-c-or-c
  for (const auto &file : reply.files()) {
    file_map->emplace(file.filename(), file.modifiedtime());
    if (display) {
      std::cout << file.filename() << std::endl;
      std::cout << "  modified: " << file.modifiedtime() << std::endl;
    }
  }
  return StatusCode::OK;
}

StatusCode DFSClientNodeP1::Stat(const std::string &filename,
                                 void *file_status) {
  //
  // STUDENT INSTRUCTION:
  //
  // Add your request to get the status of a file here. This method should
  // retrieve the status of a file on the server. Note that you won't be
  // tested on this method, but you will most likely find that you need
  // a way to get the status of a file in order to synchronize later.
  //
  // The status might include data such as name, size, mtime, crc, etc.
  //
  // The file_status is left as a void* so that you can use it to pass
  // a message type that you defined. For instance, may want to use that message
  // type after calling Stat from another method.
  //
  // The StatusCode response should be:
  //
  // StatusCode::OK - if all went well
  // StatusCode::DEADLINE_EXCEEDED - if the deadline timeout occurs
  // StatusCode::NOT_FOUND - if the file cannot be found on the server
  // StatusCode::CANCELLED otherwise
  //
  // statusOfFile message type
  FetchRequest request;
  StatusOfReply reply;
  // set deadline in client context and send the request to server, get the status
  ClientContext context;
  context.set_deadline(std::chrono::system_clock::now() +
                       std::chrono::milliseconds(deadline_timeout));
  request.set_filename(filename);
  Status status = service_stub->statusOfFile(&context, request, &reply);
  if (!status.ok()) {
    if (status.error_code() == StatusCode::NOT_FOUND) {
      return StatusCode::NOT_FOUND;
    }
    if(status.error_code() == StatusCode::DEADLINE_EXCEEDED){
      return StatusCode::DEADLINE_EXCEEDED;
    }
    return StatusCode::CANCELLED;
  }
  //assign the reply to file_status
  file_status = &reply;
  return StatusCode::OK;
}

//
// STUDENT INSTRUCTION:
//
// Add your additional code here, including
// implementations of your client methods
//