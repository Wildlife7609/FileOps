#ifndef _DFSLIB_SHARED_H
#define _DFSLIB_SHARED_H

#include <algorithm>
#include <cctype>
#include <locale>
#include <cstddef>
#include <iostream>
#include <fstream>
#include <sys/stat.h>

#include "src/dfs-utils.h"
#include "proto-src/dfs-service.grpc.pb.h"

#define DFS_BLOCK_SIZE 4096
//
// STUDENT INSTRUCTION:
//
// Add your additional code here
using dfs_service::StoreRequest;
using dfs_service::StoreReply;
using dfs_service::FetchRequest;
using dfs_service::Empty;
using dfs_service::ListReply;
using dfs_service::StatusOfReply;

using namespace std;
#endif

