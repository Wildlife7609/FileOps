#include "dfslib-servernode-p2.h"

#include <dirent.h>
#include <errno.h>
#include <getopt.h>
#include <grpcpp/grpcpp.h>
#include <sys/stat.h>

#include <chrono>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <map>
#include <mutex>
#include <shared_mutex>
#include <string>
#include <thread>

#include "dfslib-shared-p2.h"
#include "proto-src/dfs-service.grpc.pb.h"
#include "src/dfslibx-call-data.h"
#include "src/dfslibx-service-runner.h"

using grpc::Server;
using grpc::ServerBuilder;
using grpc::ServerContext;
using grpc::ServerReader;
using grpc::ServerWriter;
using grpc::Status;
using grpc::StatusCode;

using dfs_service::DFSService;

//
// STUDENT INSTRUCTION:
//
// Change these "using" aliases to the specific
// message types you are using in your `dfs-service.proto` file
// to indicate a file request and a listing of files from the server
//
using FileRequestType = CallbackListRequest;
using FileListResponseType = CallbackListReply;

extern dfs_log_level_e DFS_LOG_LEVEL;
//
// STUDENT INSTRUCTION:
//
// As with Part 1, the DFSServiceImpl is the implementation service for the rpc
// methods and message types you defined in your `dfs-service.proto` file.
//
// You may start with your Part 1 implementations of each service method.
//
// Elements to consider for Part 2:
//
// - How will you implement the write lock at the server level?
// - How will you keep track of which client has a write lock for a file?
//      - Note that we've provided a preset client_id in DFSClientNode that
//      generates
//        a client id for you. You can pass that to the server to identify the
//        current client.
// - How will you release the write lock?
// - How will you handle a store request for a client that doesn't have a write
// lock?
// - When matching files to determine similarity, you should use the
// `file_checksum` method we've provided.
//      - Both the client and server have a pre-made `crc_table` variable to
//      speed things up.
//      - Use the `file_checksum` method to compare two files, similar to the
//      following:
//
//          std::uint32_t server_crc = dfs_file_checksum(filepath,
//          &this->crc_table);
//
//      - Hint: as the crc checksum is a simple integer, you can pass it around
//      inside your message types.
//
class DFSServiceImpl final
    : public DFSService::WithAsyncMethod_CallbackList<DFSService::Service>,
      public DFSCallDataManager<FileRequestType, FileListResponseType> {
 private:
  /** The runner service used to start the service and manage asynchronicity **/
  DFSServiceRunner<FileRequestType, FileListResponseType> runner;

  /** The mount path for the server **/
  std::string mount_path;

  /** Mutex for managing the queue requests **/
  std::mutex queue_mutex;

  /** The vector of queued tags used to manage asynchronous requests **/
  std::vector<QueueRequest<FileRequestType, FileListResponseType>> queued_tags;

  /**
   * Prepend the mount path to the filename.
   *
   * @param filepath
   * @return
   */
  const std::string WrapPath(const std::string& filepath) {
    return this->mount_path + filepath;
  }

  /** CRC Table kept in memory for faster calculations **/
  CRC::Table<std::uint32_t, 32> crc_table;

  // shared mutex for write lock
  std::shared_timed_mutex WriteLock_files_mutex;
  // map for write lock, first is filepath, second is client_id
  std::map<std::string, std::string> WriteLock_files;

  bool getWriteLock_files(const std::string& filepath,
                          const std::string& client_id) {
    WriteLock_files_mutex.lock();
    if (WriteLock_files.find(filepath) != WriteLock_files.end()) {
      WriteLock_files_mutex.unlock();
      return false;
    }
    WriteLock_files[filepath] = client_id;
    WriteLock_files_mutex.unlock();
    return true;
  }

  void releaseWriteLock_files(const std::string& filepath) {
    WriteLock_files_mutex.lock();
    WriteLock_files.erase(filepath);
    WriteLock_files_mutex.unlock();
  }

 public:
  DFSServiceImpl(const std::string& mount_path,
                 const std::string& server_address, int num_async_threads)
      : mount_path(mount_path), crc_table(CRC::CRC_32()) {
    this->runner.SetService(this);
    this->runner.SetAddress(server_address);
    this->runner.SetNumThreads(num_async_threads);
    this->runner.SetQueuedRequestsCallback(
        [&] { this->ProcessQueuedRequests(); });
  }

  ~DFSServiceImpl() { this->runner.Shutdown(); }

  void Run() { this->runner.Run(); }

  /**
   * Request callback for asynchronous requests
   *
   * This method is called by the DFSCallData class during
   * an asynchronous request call from the client.
   *
   * Students should not need to adjust this.
   *
   * @param context
   * @param request
   * @param response
   * @param cq
   * @param tag
   */
  void RequestCallback(
      grpc::ServerContext* context, FileRequestType* request,
      grpc::ServerAsyncResponseWriter<FileListResponseType>* response,
      grpc::ServerCompletionQueue* cq, void* tag) {
    std::lock_guard<std::mutex> lock(queue_mutex);
    this->queued_tags.emplace_back(context, request, response, cq, tag);
  }

  /**
   * Process a callback request
   *
   * This method is called by the DFSCallData class when
   * a requested callback can be processed. You should use this method
   * to manage the CallbackList RPC call and respond as needed.
   *
   * See the STUDENT INSTRUCTION for more details.
   *
   * @param context
   * @param request
   * @param response
   */
  void ProcessCallback(ServerContext* context, FileRequestType* request,
                       FileListResponseType* response) {
    //
    // STUDENT INSTRUCTION:
    //
    // You should add your code here to respond to any CallbackList requests
    // from a client. This function is called each time an asynchronous request
    // is made from the client.
    //
    // The client should receive a list of files or modifications that represent
    // the changes this service is aware of. The client will then need to make
    // the appropriate calls based on those changes.
    //
    DIR* dir;
    struct dirent* ent;
    // check the directory
    if ((dir = opendir(this->mount_path.c_str())) != NULL) {
      while ((ent = readdir(dir)) != NULL) {
        // check the file type
        if (ent->d_type == DT_REG && ent->d_name[0] != '.') {
          // check the file existence
          struct stat buf;
          const std::string& wrapped_path = WrapPath(ent->d_name);
          if (stat(wrapped_path.c_str(), &buf) != 0) {
            dfs_log(LL_SYSINFO) << "file:-->" << wrapped_path
                                << "is not found, path is not right warning!\n";
            continue;
          }
          auto* file = response->add_files();
          file->set_filename(ent->d_name);
          file->set_modifiedtime(buf.st_mtime);
          file->set_checksum(dfs_file_checksum(wrapped_path, &this->crc_table));
        }
      }
      closedir(dir);
    } else {
      dfs_log(LL_SYSINFO) << "cannot open the directory\n";
    }
  }

  /**
   * Processes the queued requests in the queue thread
   */
  void ProcessQueuedRequests() {
    while (true) {
      //
      // STUDENT INSTRUCTION:
      //
      // You should add any synchronization mechanisms you may need here in
      // addition to the queue management. For example, modified files checks.
      //
      // Note: you will need to leave the basic queue structure as-is, but you
      // may add any additional code you feel is necessary.
      //

      // Guarded section for queue
      {
        dfs_log(LL_DEBUG2) << "Waiting for queue guard";
        std::lock_guard<std::mutex> lock(queue_mutex);

        for (QueueRequest<FileRequestType, FileListResponseType>&
                 queue_request : this->queued_tags) {
          this->RequestCallbackList(queue_request.context,
                                    queue_request.request,
                                    queue_request.response, queue_request.cq,
                                    queue_request.cq, queue_request.tag);
          queue_request.finished = true;
        }

        // any finished tags first
        this->queued_tags.erase(
            std::remove_if(
                this->queued_tags.begin(), this->queued_tags.end(),
                [](QueueRequest<FileRequestType, FileListResponseType>&
                       queue_request) { return queue_request.finished; }),
            this->queued_tags.end());
      }
    }
  }

  //
  // STUDENT INSTRUCTION:
  //
  // Add your additional code here, including
  // the implementations of your rpc protocol methods.
  //

  // grpc::Status CallbackList(::grpc::ClientContext* context,
  //                           const ::dfs_service::CallbackListRequest&
  //                           request,
  //                           ::dfs_service::ListReply* response) override {

  //   }

  grpc::Status requestWriteLock(
      grpc::ServerContext* context,
      const dfs_service::WriteLockRequest* request,
      dfs_service::WriteLockReply* response) override {
    std::string filepath = this->WrapPath(request->filename());
    std::string client_id = request->clientid();
    dfs_log(LL_SYSINFO) << "client_id: " << client_id;
    // Check if file is already locked
    if (getWriteLock_files(filepath, client_id)) {
      dfs_log(LL_SYSINFO) << "File is locked by the client\n";
      return Status::OK;
    }
    return Status(StatusCode::RESOURCE_EXHAUSTED, "File is already locked");
  }

  grpc::Status storeFile(
      grpc::ServerContext* context,
      grpc::ServerReader<::dfs_service::StoreRequest>* reader,
      dfs_service::StoreReply* response) override {
    // store request message type
    StoreRequest request;
    // get the metadata
    auto metadata = context->client_metadata();
    std::string filename =
        std::string(metadata.find("filename")->second.data(),
                    metadata.find("filename")->second.length());
    std::string modified_time =
        std::string(metadata.find("modifiedtime")->second.data(),
                    metadata.find("modifiedtime")->second.length());
    std::string checksum =
        std::string(metadata.find("checksum")->second.data(),
                    metadata.find("checksum")->second.length());
    dfs_log(LL_SYSINFO) << "client want to store filename: " << filename;
    dfs_log(LL_SYSINFO) << "client checksum: " << checksum;
    dfs_log(LL_SYSINFO) << "client modified_time: " << modified_time;
    int modified_time_client = stoi(modified_time);
    uint32_t checksum_client = stoi(checksum);
    const std::string& wrapped_path = WrapPath(filename);
    struct stat buffer;
    if (stat(wrapped_path.c_str(), &buffer) == 0) {
      dfs_log(LL_SYSINFO) << "server file:-->" << wrapped_path << "is found\n";
      if (modified_time_client < buffer.st_mtime) {
        dfs_log(LL_SYSINFO)
            << "file:-->" << wrapped_path << "server has latest version\n";
        releaseWriteLock_files(filename);
        return grpc::Status(StatusCode::ALREADY_EXISTS,
                            "server has latest version");
      }
      if (checksum_client ==
              dfs_file_checksum(wrapped_path, &this->crc_table) &&
          modified_time_client == buffer.st_mtime) {
        dfs_log(LL_SYSINFO)
            << "file:-->" << wrapped_path << "is already exist\n";
        releaseWriteLock_files(filename);
        return grpc::Status(StatusCode::ALREADY_EXISTS,
                            "file already exists, same version");
      }
      if (modified_time_client > buffer.st_mtime &&
          checksum_client ==
              dfs_file_checksum(wrapped_path, &this->crc_table)) {
        dfs_log(LL_SYSINFO) << "file:-->" << wrapped_path
                            << "server need update the modified time\n";
        utimbuf time_buf;
        time_buf.modtime = modified_time_client;
        utime(wrapped_path.c_str(), &time_buf);
        releaseWriteLock_files(filename);
        return grpc::Status(StatusCode::OK, "server already update the modified time");
      }
    }
    // handle error
    try {
      // operator the file to receive the file content
      std::ofstream file_stream(wrapped_path);
      if (!file_stream.is_open()) {
        releaseWriteLock_files(filename);
        return grpc::Status(StatusCode::CANCELLED, "File cannot be opened");
      }
      // read the file content and write to the file, while Read() returns true
      // which means the file is not end
      while (reader->Read(&request)) {
        // check the deadline before write the file
        if (context->IsCancelled()) {
          dfs_log(LL_SYSINFO) << "Deadline exceeded\n";
          releaseWriteLock_files(filename);
          return grpc::Status(StatusCode::DEADLINE_EXCEEDED,
                              "Deadline exceeded");
        }
        file_stream.write(request.filecontent().c_str(),
                          request.filecontent().length());
        dfs_log(LL_SYSINFO)
            << "write the file:-->" << wrapped_path << "bytes_read:-->"
            << request.filecontent().length() << "\n";
      }
      file_stream.close();
    } catch (std::exception& e) {
      dfs_log(LL_SYSINFO) << "storeFile exception\n";
      releaseWriteLock_files(filename);
      return grpc::Status(StatusCode::CANCELLED, "storeFile exception");
    }
    struct stat buf;
    if (stat(wrapped_path.c_str(), &buf) != 0) {
      dfs_log(LL_SYSINFO) << "file:-->" << wrapped_path << "is not found\n";
      releaseWriteLock_files(filename);
      return grpc::Status(StatusCode::CANCELLED, "file not found");
    }
    int modified_time_server = buf.st_mtime;

    dfs_log(LL_SYSINFO) << "file:-->" << wrapped_path
                        << "is stored successfully\n";
    response->set_modifiedtime(modified_time_server);
    releaseWriteLock_files(filename);
    return grpc::Status::OK;
  }

  grpc::Status fetchFile(
      grpc::ServerContext* context, const dfs_service::FetchRequest* request,
      grpc::ServerWriter<::dfs_service::FetchReply>* writer) override {
    // fetch reply message type
    FetchReply reply;
    // get the file name
    string filename = request->filename();
    const std::string& wrapped_path = WrapPath(filename);
    dfs_log(LL_SYSINFO) << "get the file path:-->" << wrapped_path << "\n";
    struct stat buf;
    // check the file existence
    if (stat(wrapped_path.c_str(), &buf) != 0) {
      dfs_log(LL_SYSINFO) << "file:-->" << wrapped_path << "is not found\n";
      return grpc::Status(StatusCode::NOT_FOUND, "file not found");
    }
    context->AddInitialMetadata(
        "checksum",
        to_string(dfs_file_checksum(wrapped_path, &this->crc_table)));
    context->AddInitialMetadata("modifiedtime", to_string(buf.st_mtime));
    int file_size = buf.st_size;
    dfs_log(LL_SYSINFO) << "size:-->" << file_size << "\n";
    // handle error
    try {
      // get the file size and open the file
      std::ifstream file_strean(wrapped_path);
      if (!file_strean.is_open()) {
        dfs_log(LL_SYSINFO)
            << "file:-->" << wrapped_path << "cannot be opened\n";
        return grpc::Status(StatusCode::CANCELLED, "cannot be opened");
      }
      int bytes_read = 0;
      // read and write the file
      while (file_size > 0) {
        // check the deadline before read the file
        if (context->IsCancelled()) {
          dfs_log(LL_SYSINFO) << "Deadline exceeded\n";
          return grpc::Status(StatusCode::DEADLINE_EXCEEDED,
                              "Mismatched status code");
        }
        char* buffer = new char[DFS_BLOCK_SIZE];
        memset(buffer, 0, DFS_BLOCK_SIZE);
        bytes_read = std::min(file_size, DFS_BLOCK_SIZE);
        file_strean.read(buffer, bytes_read);
        file_size -= bytes_read;
        reply.set_filecontent(buffer, bytes_read);
        writer->Write(reply);
        dfs_log(LL_SYSINFO) << "write the file:-->" << filename
                            << "bytes_read:-->" << bytes_read << "\n";
        delete[] buffer;
      }
      file_strean.close();
    } catch (std::exception& e) {
      dfs_log(LL_SYSINFO) << "fetchFile exception\n";
      return grpc::Status(StatusCode::CANCELLED, "fetchFile exception");
    }
    dfs_log(LL_SYSINFO) << "file:-->" << filename
                        << "is fetched successfully\n";
    return grpc::Status::OK;
  }

  grpc::Status deleteFile(grpc::ServerContext* context,
                          const dfs_service::DeleteRequest* request,
                          dfs_service::DeleteReply* response) override {
    // Implement deleteFile logic here
    const std::string& wrapped_path = WrapPath(request->filename());
    if (context->IsCancelled()) {
      releaseWriteLock_files(wrapped_path);
      return grpc::Status(StatusCode::DEADLINE_EXCEEDED,
                          "Mismatched status code");
    }
    struct stat buffer;
    if (stat(wrapped_path.c_str(), &buffer) != 0) {
      releaseWriteLock_files(wrapped_path);
      return grpc::Status(StatusCode::NOT_FOUND, "Mismatched status code");
    }
    // check the file existence
    if (remove(wrapped_path.c_str()) != 0) {
      releaseWriteLock_files(wrapped_path);
      return grpc::Status(StatusCode::CANCELLED, "Mismatched status code");
    }
    releaseWriteLock_files(wrapped_path);
    return grpc::Status::OK;
  }

  grpc::Status listFiles(grpc::ServerContext* context,
                         const dfs_service::ListRequest* request,
                         dfs_service::ListReply* response) override {
    // Implement listFiles logic here reference:
    // https://stackoverflow.com/questions/612097/how-can-i-get-the-list-of-files-in-a-directory-using-c-or-c
    // since my cpp version is 9, I cannot use std::filesystem
    DIR* dir;
    struct dirent* ent;
    // check the directory
    if ((dir = opendir(this->mount_path.c_str())) != NULL) {
      while ((ent = readdir(dir)) != NULL) {
        if (context->IsCancelled()) {
          dfs_log(LL_SYSINFO) << "Deadline exceeded, context is cancelled\n";
          return grpc::Status(StatusCode::DEADLINE_EXCEEDED,
                              "Mismatched status code");
        }
        // check the file type
        if (ent->d_type == DT_REG) {
          auto* file = response->add_files();
          file->set_filename(ent->d_name);
          struct stat buf;
          const std::string& wrapped_path = WrapPath(ent->d_name);
          if (stat(wrapped_path.c_str(), &buf) != 0) {
            dfs_log(LL_SYSINFO) << "file:-->" << wrapped_path
                                << "is not found, path is not right warning!\n";
            return grpc::Status(StatusCode::NOT_FOUND,
                                "Mismatched status code");
          }
          file->set_modifiedtime(buf.st_mtime);
        }
      }
      closedir(dir);
    } else {
      return grpc::Status(StatusCode::CANCELLED, "Mismatched status code");
    }
    return grpc::Status::OK;
  }

  grpc::Status statusOfFile(grpc::ServerContext* context,
                            const dfs_service::StatusOfRequest* request,
                            dfs_service::StatusOfReply* response) override {
    // Implement statusOfFile logic here
    if (context->IsCancelled()) {
      return grpc::Status(StatusCode::DEADLINE_EXCEEDED,
                          "Mismatched status code");
    }
    struct stat file_attr;
    const std::string& wrapped_path = WrapPath(request->filename());
    if (stat(wrapped_path.c_str(), &file_attr) != 0) {
      return grpc::Status(StatusCode::NOT_FOUND, "Mismatched status code");
    }
    response->set_size(file_attr.st_size);
    response->set_creationtime(file_attr.st_ctime);
    response->set_modifiedtime(file_attr.st_mtime);
    return grpc::Status::OK;
  }
};

//
// STUDENT INSTRUCTION:
//
// The following three methods are part of the basic DFSServerNode
// structure. You may add additional methods or change these slightly
// to add additional startup/shutdown routines inside, but be aware that
// the basic structure should stay the same as the testing environment
// will be expected this structure.
//
/**
 * The main server node constructor
 *
 * @param mount_path
 */
DFSServerNode::DFSServerNode(const std::string& server_address,
                             const std::string& mount_path,
                             int num_async_threads,
                             std::function<void()> callback)
    : server_address(server_address),
      mount_path(mount_path),
      num_async_threads(num_async_threads),
      grader_callback(callback) {}
/**
 * Server shutdown
 */
DFSServerNode::~DFSServerNode() noexcept {
  dfs_log(LL_SYSINFO) << "DFSServerNode shutting down";
}

/**
 * Start the DFSServerNode server
 */
void DFSServerNode::Start() {
  DFSServiceImpl service(this->mount_path, this->server_address,
                         this->num_async_threads);

  dfs_log(LL_SYSINFO) << "DFSServerNode server listening on "
                      << this->server_address;
  service.Run();
}

//
// STUDENT INSTRUCTION:
//
// Add your additional definitions here
//
