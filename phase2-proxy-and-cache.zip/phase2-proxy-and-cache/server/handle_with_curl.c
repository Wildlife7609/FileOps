#include "gfserver.h"
#include "proxy-student.h"

#define MAX_REQUEST_N 822
#define BUFSIZE (6200)

/*
 * Replace with an implementation of handle_with_curl and
 * any other functions you may need

 __.__
 */

struct MemoryStruct {
  char *memory;
  size_t size;
};
// reference: https://curl.se/libcurl/c/getinmemory.html
static size_t write_callback(char *contents, size_t size, size_t nmemb,
                             void *userdata) {
  size_t realsize = size * nmemb;
  struct MemoryStruct *mem = (struct MemoryStruct *)userdata;
  char *ptr = realloc(mem->memory, mem->size + realsize + 1);
  if (!ptr) {
    fprintf(stderr, "not enough memory (realloc returned NULL)\n");
    return 0;
  }
  mem->memory = ptr;
  memcpy(&(mem->memory[mem->size]), contents, realsize);
  mem->size += realsize;
  mem->memory[mem->size] = 0;
  return realsize;
}

ssize_t handle_with_curl(gfcontext_t *ctx, const char *path, void *arg) {
  (void)ctx;
  (void)arg;
  (void)path;
  /* not implemented */

  CURL *myHandle;
  CURLcode result;
  char url[MAX_REQUEST_N] = "";
  char *server = arg;
  strncpy(url, server, MAX_REQUEST_N);
  strncat(url, path, MAX_REQUEST_N);
  struct MemoryStruct chunk;
  chunk.memory = malloc(1);
  chunk.size = 0;
  myHandle = curl_easy_init();
  ssize_t byte_transferred = 0;
  if (myHandle) {
    curl_easy_setopt(myHandle, CURLOPT_URL, url);
    curl_easy_setopt(myHandle, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(myHandle, CURLOPT_WRITEDATA, (void *)&chunk);
    result = curl_easy_perform(myHandle);
    if (result == CURLE_OK) {
      size_t response_code = 0;
      curl_easy_getinfo(myHandle, CURLINFO_RESPONSE_CODE, &response_code);
      if (response_code == 200) {
        gfs_sendheader(ctx, GF_OK, chunk.size);
        byte_transferred = gfs_send(ctx, chunk.memory, chunk.size);
      } else if (response_code == 400) {
        gfs_sendheader(ctx, GF_FILE_NOT_FOUND, 0);

      } else {
        gfs_sendheader(ctx, GF_ERROR, 0);
      }
    } else {
      return SERVER_FAILURE;
    }
  }
  free(chunk.memory);
  curl_easy_cleanup(myHandle);
  return byte_transferred;
}

/*
 * We provide a dummy version of handle_with_file that invokes handle_with_curl
 * as a convenience for linking.  We recommend you simply modify the proxy to
 * call handle_with_curl directly

 __.__
 */
ssize_t handle_with_file(gfcontext_t *ctx, const char *path, void *arg) {
  return handle_with_curl(ctx, path, arg);
}
