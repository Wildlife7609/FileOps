       /*
 *  This file is for use by students to define anything they wish. 
 It is used by both proxy server implementation.
 */
 #ifndef __SERVER_STUDENT_H__836
 #define __SERVER_STUDENT_H__836
 
 #endif // __SERVER_STUDENT_H__836