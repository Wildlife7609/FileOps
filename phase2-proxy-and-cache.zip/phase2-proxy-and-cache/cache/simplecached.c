#include <curl/curl.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <limits.h>
#include <printf.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/signal.h>
#include <unistd.h>

#include "cache-student.h"
#include "gfserver.h"
#include "shm_channel.h"
#include "simplecache.h"

// CACHE_FAILURE
#if !defined(CACHE_FAILURE)
#define CACHE_FAILURE (-1)
#endif

#define MAX_CACHE_REQUEST_LEN 6200
#define MAX_SIMPLE_CACHE_QUEUE_SIZE 824

// global variables
const char *mq_name = "/message_queue_command_channel";
unsigned long int cache_delay;
// initialize mqd_t variable
mqd_t mq = -1;

static void _sig_handler(int signo) {
  if (signo == SIGTERM || signo == SIGINT) {
    /*you should do IPC cleanup here*/
    mq_unlink(mq_name);
    simplecache_destroy();
    exit(signo);
  }
}

#define USAGE                                                                \
  "usage:\n"                                                                 \
  "  simplecached [options]\n"                                               \
  "options:\n"                                                               \
  "  -c [cachedir]       Path to static files (Default: ./)\n"               \
  "  -t [thread_count]   Thread count for work queue (Default is 42, Range " \
  "is 1-235711)\n"                                                           \
  "  -d [delay]          Delay in simplecache_get (Default is 0, Range is "  \
  "0-2500000 (microseconds)\n "                                              \
  "  -h                  Show this help message\n"

// OPTIONS
static struct option gLongOptions[] = {
    {"cachedir", required_argument, NULL, 'c'},
    {"nthreads", required_argument, NULL, 't'},
    {"help", no_argument, NULL, 'h'},
    {"hidden", no_argument, NULL, 'i'},       /* server side */
    {"delay", required_argument, NULL, 'd'},  // delay.
    {NULL, 0, NULL, 0}};

void Usage() { fprintf(stdout, "%s", USAGE); }

// reference about message queue attr: https://w3.cs.jmu.edu/kirkpams/OpenCSF/Books/csf/html/MQueues.html#:~:text=For%20instance%2C%20the%20default%20message,)%2C%20it%20will%20receive%20nothing.
void *worker_threads(void *arg) {
  while (1) {
    // struct mq_attr attr;
    // if (mq_getattr(mq, &attr) == -1) {
    //   perror("mq_getattr error");
    // }
    comm_channel_t message = {0};
    if (mq_receive(mq, (char *)&message, sizeof(message), 0) == -1) {
      perror("mq_receive error");
    }
    // comm_channel_t *message = (comm_channel_t *)buffer;
    // printf("message received. path: %s, segsize: %lu\n", message->path,
    //        message->segsize);

    // open shared memory segment
    int shm_fd = shm_open(message.shm_name, O_RDWR, 0666);
    if (shm_fd == -1) {
      fprintf(stderr, "shm_open error\n");
    }
    void *addr = mmap(NULL, message.segsize, PROT_READ | PROT_WRITE, MAP_SHARED,
                     shm_fd, 0);
    if (addr == MAP_FAILED) {
      fprintf(stderr, "mmap error\n");
    }
    data_channel_t *shm_memory = (data_channel_t *)addr;
    // find the file in cache
    int fd = simplecache_get(message.path);
    if (fd == -1) {
      printf("file %s not found\n", message.path);
      shm_memory->status = 404;
      sem_post(&shm_memory->read_sem);
    } else {
      // get file length
      struct stat st;
      fstat(fd, &st);
      size_t byte_sent = 0;
      size_t buffer_size = message.segsize - sizeof(data_channel_t);
      // char buffer[buffer_size];
      // memset(buffer, 0, buffer_size);
      printf("file %s found, file len: %lu, buffer size: %lu\n", message.path, st.st_size, buffer_size);
      while (byte_sent < st.st_size) {
        sem_wait(&shm_memory->write_sem);
        shm_memory->status = 200;
        shm_memory->filelen = st.st_size;
        ssize_t file_read = pread(fd, addr + sizeof(data_channel_t), buffer_size, byte_sent);
        // memcpy(addr + sizeof(data_channel_t), buffer, file_read);
        byte_sent += file_read;
        shm_memory->byte_sent_each_time = file_read;
        // printf("bytes sent: %lu, file len: %lu\n", byte_sent, st.st_size);
        sem_post(&shm_memory->read_sem);
      }
      printf("file %s sent. bytes_sent: %lu, file_len: %lu\n", message.path,
             byte_sent, st.st_size);
    }
  }
}

int main(int argc, char **argv) {
  int nthreads = 11;
  char *cachedir = "locals.txt";
  char option_char;

  /* disable buffering to stdout */
  setbuf(stdout, NULL);

  while ((option_char = getopt_long(argc, argv, "d:ic:hlt:x", gLongOptions,
                                    NULL)) != -1) {
    switch (option_char) {
      default:
        Usage();
        exit(1);
      case 't':  // thread-count
        nthreads = atoi(optarg);
        break;
      case 'h':  // help
        Usage();
        exit(0);
        break;
      case 'c':  // cache directory
        cachedir = optarg;
        break;
      case 'd':
        cache_delay = (unsigned long int)atoi(optarg);
        break;
      case 'i':  // server side usage
      case 'o':  // do not modify
      case 'a':  // experimental
        break;
    }
  }

  if (cache_delay > 2500001) {
    fprintf(stderr, "Cache delay must be less than 2500001 (us)\n");
    exit(__LINE__);
  }

  if ((nthreads > 211804) || (nthreads < 1)) {
    fprintf(stderr, "Invalid number of threads must be in between 1-211804\n");
    exit(__LINE__);
  }
  if (SIG_ERR == signal(SIGINT, _sig_handler)) {
    fprintf(stderr, "Unable to catch SIGINT...exiting.\n");
    exit(CACHE_FAILURE);
  }
  if (SIG_ERR == signal(SIGTERM, _sig_handler)) {
    fprintf(stderr, "Unable to catch SIGTERM...exiting.\n");
    exit(CACHE_FAILURE);
  }
  /*Initialize cache*/
  simplecache_init(cachedir);

 //if message queue doesn't exist, sleep to wait for it
  while (-1 == (mq = mq_open(mq_name, O_RDONLY, 0666, NULL))) {
    printf("message queue open error. sleep and retry\n");
    sleep(1);
  }
  // create threads
  pthread_t threads[nthreads];
  for (int i = 0; i < nthreads; i++) {
    pthread_create(&threads[i], NULL, worker_threads, NULL);
  }
  // keep boss thread alive
  for (int i = 0; i < nthreads; i++) {
    pthread_join(threads[i], NULL);
  }

  // Line never reached
  return -1;
}
