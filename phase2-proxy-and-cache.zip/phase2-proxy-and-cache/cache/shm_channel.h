// In case you want to implement the shared memory IPC as a library
// You may use this file. It is optional.
//
