/*
 *  To be used by students
 */
#ifndef __CACHE_STUDENT_H__836
#define __CACHE_STUDENT_H__836

#include <mqueue.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h> 

#include "steque.h"

#define MAX_REQUEST_LENGTH 822
#define FILE_NOT_FOUND 404
#define OK 200

// command channel use message queue, proxy send to cache
typedef struct comm_channel {
  char path[MAX_REQUEST_LENGTH];
  char shm_name[10];
  size_t segsize;
} comm_channel_t;

// data channel struct manage shared memory and stored in shared memory
typedef struct data_channel {
  char shm_name[10];
  int status;
  size_t segsize;
  size_t filelen;
  size_t byte_sent_each_time;
  sem_t read_sem;
  sem_t write_sem;
} data_channel_t;

// global variables
extern steque_t *shm_queue;
extern const char *mq_name;

#endif  // __CACHE_STUDENT_H__836