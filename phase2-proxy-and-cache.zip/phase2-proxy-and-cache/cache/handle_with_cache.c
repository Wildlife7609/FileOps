#include "cache-student.h"
#include "gfserver.h"

#define BUFSIZE (836)
// global variables
steque_t *shm_queue = NULL;
pthread_mutex_t shm_queue_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t shm_queue_cond = PTHREAD_COND_INITIALIZER;
const char *mq_name = "/message_queue_command_channel";
mqd_t mq = -1;

ssize_t handle_with_cache(gfcontext_t *ctx, const char *path, void *arg) {
  // set up message queue, reference:
  // https://stackoverflow.com/questions/3056307/how-do-i-use-mqueue-in-a-c-program-on-a-linux-based-system
  comm_channel_t request;
  memset(&request, 0, sizeof(comm_channel_t));
  strcpy(request.path, path);
  // get a shared memory from the queue
  pthread_mutex_lock(&shm_queue_mutex);
  while (steque_isempty(shm_queue)) {
    pthread_cond_wait(&shm_queue_cond, &shm_queue_mutex);
  }
  data_channel_t *shm_memory = (data_channel_t *)steque_pop(shm_queue);
  pthread_mutex_unlock(&shm_queue_mutex);
  // bind a shared memory space to a message queue
  strcpy(request.shm_name, shm_memory->shm_name);
  request.segsize = shm_memory->segsize;
  // send request
  if (mq_send(mq, (const char *)&request, sizeof(request), 0) == -1) {
    perror("mq_send error");
  }
  printf(
      "sent message to message queue. message size: %lu, path: %s, segsize: "
      "%lu\n",
      sizeof(request), request.path, request.segsize);
  // open the shared memory
  int fd = shm_open(shm_memory->shm_name, O_RDWR, 0);
  if (fd == -1) {
    perror("shm_open error");
  }
  char *addr = mmap(NULL, shm_memory->segsize, PROT_READ, MAP_SHARED, fd, 0);
  if (addr == MAP_FAILED) {
    perror("mmap error");
  }
  // process the response
  size_t bytes_sent = 0;
  bool header_sent = false;
  while (1) {
    sem_wait(&shm_memory->read_sem);
    if (shm_memory->status == 404) {
      printf("file %s not found\n", path);
      gfs_sendheader(ctx, GF_FILE_NOT_FOUND, 0);
      break;
    } else if (shm_memory->status == 200) {
      if (!header_sent) {
        printf("file %s found, file len: %lu. sending header\n", path,
               shm_memory->filelen);
        gfs_sendheader(ctx, GF_OK, shm_memory->filelen);
        header_sent = true;
      }
      bytes_sent += gfs_send(ctx, addr + sizeof(data_channel_t),
                             shm_memory->byte_sent_each_time);
      if (bytes_sent >= shm_memory->filelen) {
        break;
      }
      sem_post(&shm_memory->write_sem);
    }
  }
  // init the fields and put the shared memory back to the queue
  shm_memory->filelen = 0;
  shm_memory->status = 0;
  shm_memory->byte_sent_each_time = 0;
  sem_init(&shm_memory->read_sem, 1, 0);
  sem_init(&shm_memory->write_sem, 1, 1);
  pthread_mutex_lock(&shm_queue_mutex);
  steque_enqueue(shm_queue, shm_memory);
  pthread_mutex_unlock(&shm_queue_mutex);
  pthread_cond_signal(&shm_queue_cond);
  return bytes_sent;
}

// reference:
// https://man7.org/training/download/lusp_pshm_slides-mkerrisk-man7.org.pdf
// https://stackoverflow.com/questions/3056307/how-do-i-use-mqueue-in-a-c-program-on-a-linux-based-system
void init_shm(unsigned int nsegments, size_t segsize) {
  shm_queue = (steque_t *)malloc(sizeof(steque_t));
  steque_init(shm_queue);
  struct mq_attr attr;
  /* initialize the queue attributes */
  attr.mq_flags = 0;
  attr.mq_maxmsg = 10;
  attr.mq_msgsize = sizeof(comm_channel_t);
  attr.mq_curmsgs = 0;
  mq_unlink(mq_name);
  // set up message queue, if &attr is NULL, then receive need to specify the
  // MSG_MAXSIZE, or I need set up &attr to set the max size of message
  mq = mq_open(mq_name, O_WRONLY | O_CREAT | O_EXCL, 0666, &attr);
  for (int i = 0; i < nsegments; i++) {
    char name[10] = {0};
    // generate a unique shm_name, if this name has linked to a shm, unlink
    // it.
    sprintf(name, "/shm_%d", i);
    shm_unlink(name);
    // open for read or write
    int fd = shm_open(name, O_CREAT | O_EXCL | O_RDWR, S_IRUSR | S_IWUSR);
    if (fd == -1) {
      perror("shm_open error");
    }
    if (ftruncate(fd, segsize) == -1) {
      perror("ftruncate error");
    }
    // shm_data is struct to manage the shared memory, mmap() size need
    // include the size of shm_data
    void *addr = mmap(NULL, segsize, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED) {
      perror("mmap error");
    }
    // put data_channel_t in the shared memory
    data_channel_t *shm_memory = (data_channel_t *)addr;
    strncpy(shm_memory->shm_name, name, 10);
    shm_memory->segsize = segsize;
    shm_memory->filelen = 0;
    shm_memory->status = 0;
    shm_memory->byte_sent_each_time = 0;
    sem_init(&(shm_memory->read_sem), 1, 0);
    sem_init(&(shm_memory->write_sem), 1, 1);
    // put the shared memory in the queue
    pthread_mutex_lock(&shm_queue_mutex);
    steque_enqueue(shm_queue, shm_memory);
    pthread_mutex_unlock(&shm_queue_mutex);
    pthread_cond_signal(&shm_queue_cond);
  }
}
