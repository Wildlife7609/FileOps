/*
 *  This file is for use by students to define anything they wish.  It is used
 * by the gf server implementation
 */
#ifndef __GF_SERVER_STUDENT_H__
#define __GF_SERVER_STUDENT_H__

#include "content.h"
#include "gf-student.h"
#include "gfserver.h"
#include "steque.h"
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

extern pthread_mutex_t queue_mutex;
extern pthread_cond_t in_queue;
extern steque_t *queue;

typedef struct queue_element queue_element;

struct queue_element {
  gfcontext_t *ctx;
  const char *path;
};

//item for the queue
steque_item creat_item(gfcontext_t *ctx, const char *path);

void init_threads(size_t numthreads);
void cleanup_threads();

#endif  // __GF_SERVER_STUDENT_H__
