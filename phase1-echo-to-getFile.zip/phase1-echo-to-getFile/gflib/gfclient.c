
#include <stdlib.h>

#include "gfclient-student.h"

void *get_in_addr(struct sockaddr *sa) {
  if (sa->sa_family == AF_INET) {
    return &(((struct sockaddr_in *)sa)->sin_addr);
  }

  return &(((struct sockaddr_in6 *)sa)->sin6_addr);
}

const gfstatus_t str_status_to_gfstatus_t(const char *str_status) {
  if (strcmp(str_status, "OK") == 0) {
    return GF_OK;
  } else if (strcmp(str_status, "FILE_NOT_FOUND") == 0) {
    return GF_FILE_NOT_FOUND;
  } else if (strcmp(str_status, "INVALID") == 0) {
    return GF_INVALID;
  } else if (strcmp(str_status, "ERROR") == 0) {
    return GF_ERROR;
  } else {
    return GF_ERROR;
  }
}

// Modify this file to implement the interface specified in
// gfclient.h.

// optional function for cleaup processing.
void gfc_cleanup(gfcrequest_t **gfr) {
  free(*gfr);
  *gfr = NULL;
}

gfcrequest_t *gfc_create() {
  gfcrequest_t *gfr = malloc(sizeof(gfcrequest_t));
  memset(gfr, 0, sizeof(gfcrequest_t));
  gfr->port = 10680;
  gfr->server = "127.0.0.1";
  gfr->headerarg = NULL;
  gfr->path = NULL;
  gfr->headerfunc = NULL;
  gfr->writearg = NULL;
  gfr->writefunc = NULL;
  gfr->bytesreceived = 0;
  gfr->filelen = 0;
  gfr->status = GF_OK;
  return gfr;
}

size_t gfc_get_bytesreceived(gfcrequest_t **gfr) {
  return (*gfr)->bytesreceived;
}

size_t gfc_get_filelen(gfcrequest_t **gfr) { return (*gfr)->filelen; }

gfstatus_t gfc_get_status(gfcrequest_t **gfr) { return (*gfr)->status; }

void gfc_global_init() {}

void gfc_global_cleanup() {}

int gfc_perform(gfcrequest_t **gfr) {
  struct addrinfo *servinfo;
  // hints.ai_family = AF_UNSPEC;  // use AF_INET6 to force IPv6
  // hints.ai_socktype = SOCK_STREAM;
  char port[10] = {0};
  sprintf(port, "%hu", (*gfr)->port);
  getaddrinfo((*gfr)->server, port, NULL, &servinfo);
  int clientSocket = socket(servinfo->ai_family, SOCK_STREAM, 0);

  printf("Connecting to %s:%d\n", (*gfr)->server, (*gfr)->port);
  if (connect(clientSocket, servinfo->ai_addr, sizeof(*(servinfo->ai_addr))) ==
      -1) {
    close(clientSocket);
    freeaddrinfo(servinfo);
    return -1;
  }
  char message[512];
  memset(message, 0, 512);
  printf("Sending GETFILE GET %s\r\n\r\n", (*gfr)->path);
  sprintf(message, "GETFILE GET %s\r\n\r\n", (*gfr)->path);
  send(clientSocket, message, strlen(message), 0);

  char buffer[BUFFER_SIZE] = {0};
  int header_received = 0, file_received = 0;
  char header[512] = {0};
  char scheme[50] = {0}, status[50] = {0};
  unsigned long long file_len = 0;
  char *end_of_header = NULL;
  while (1) {
    int received = recv(clientSocket, buffer + header_received, BUFFER_SIZE, 0);
    if (received > 0) {
      header_received += received;
    }

    end_of_header = strstr(buffer, "\r\n\r\n");
    if (end_of_header != NULL) {
      break;
    }
    if (received <= 0) {
      break;
    }
  }
  if (end_of_header == NULL) {
    (*gfr)->status = GF_INVALID;
    close(clientSocket);
    freeaddrinfo(servinfo);

    return -1;
  }
  int header_len = end_of_header - buffer;
  if ((*gfr)->headerfunc != NULL) {
    (*(*gfr)->headerfunc)(buffer, header_len, (*gfr)->headerarg);
  }
  strncpy(header, buffer, header_len);
  printf("header: %s, buffer: %s\n", header, buffer);
  // format an unsigned long long int using printf is %llu
  sscanf(header, "%s %s %llu", scheme, status, &file_len);
  if (strcmp(scheme, "GETFILE") != 0 ||
      (strcmp(status, "OK") != 0 && strcmp(status, "FILE_NOT_FOUND") != 0 &&
       strcmp(status, "INVALID") != 0 && strcmp(status, "ERROR") != 0)) {
    (*gfr)->status = GF_INVALID;
    close(clientSocket);
    freeaddrinfo(servinfo);

    return -1;
  }
  file_received = header_received - header_len - 4;
  printf(
      "header_received: %d, header_len: %d, file_len: %llu, file_received: "
      "%d\n",
      header_received, header_len, file_len, file_received);
  if (file_received > 0) {
    if ((*gfr)->writefunc != NULL) {
      (*(*gfr)->writefunc)(end_of_header + 4, file_received, (*gfr)->writearg);
    }
  }

  (*gfr)->filelen = file_len;
  (*gfr)->status = str_status_to_gfstatus_t(status);
  if ((*gfr)->status == GF_OK) {
    while (1) {
      int received = recv(clientSocket, buffer, BUFFER_SIZE, 0);
      if (received <= 0) {
        break;
      }
      file_received += received;
      (*gfr)->bytesreceived = file_received;
      printf("received: %d, file_received: %d\n", received, file_received);
      if ((*gfr)->writefunc != NULL) {
        (*(*gfr)->writefunc)(buffer, received, (*gfr)->writearg);
      }
      if (file_received >= file_len) {
        break;
      }
    }
    if (file_received < file_len) {
      close(clientSocket);
      freeaddrinfo(servinfo);

      return -1;
    }
  }

  // char *endofheader = strstr(buffer, "\r\n\r\n");
  // if (endofheader == NULL) {
  //   close(clientSocket);
  //   return -1;
  // }
  // (*(*gfr)->headerfunc)(buffer, endofheader - buffer, (*gfr)->headerarg);
  // endofheader += 4;
  // (*gfr)->writefunc(endofheader, response_len - (endofheader - buffer),
  //                   (*gfr)->writearg);
  // (*gfr)->bytesreceived = response_len - (endofheader - buffer);
  // (*gfr)->filelen = response_len - (endofheader - buffer);
  // (*gfr)->status = GF_OK;
  close(clientSocket);
  freeaddrinfo(servinfo);

  return 0;
}

void gfc_set_port(gfcrequest_t **gfr, unsigned short port) {
  (*gfr)->port = port;
}

void gfc_set_server(gfcrequest_t **gfr, const char *server) {
  (*gfr)->server = server;
}

void gfc_set_headerarg(gfcrequest_t **gfr, void *headerarg) {
  (*gfr)->headerarg = headerarg;
}

void gfc_set_path(gfcrequest_t **gfr, const char *path) { (*gfr)->path = path; }

void gfc_set_headerfunc(gfcrequest_t **gfr,
                        void (*headerfunc)(void *, size_t, void *)) {
  (*gfr)->headerfunc = headerfunc;
}

void gfc_set_writearg(gfcrequest_t **gfr, void *writearg) {
  (*gfr)->writearg = writearg;
}

void gfc_set_writefunc(gfcrequest_t **gfr,
                       void (*writefunc)(void *, size_t, void *)) {
  (*gfr)->writefunc = writefunc;
}

const char *gfc_strstatus(gfstatus_t status) {
  const char *strstatus = "UNKNOWN";

  switch (status) {
    case GF_OK: {
      strstatus = "OK";
    } break;

    case GF_FILE_NOT_FOUND: {
      strstatus = "FILE_NOT_FOUND";
    } break;

    case GF_INVALID: {
      strstatus = "INVALID";
    } break;

    case GF_ERROR: {
      strstatus = "ERROR";
    } break;
  }

  return strstatus;
}
