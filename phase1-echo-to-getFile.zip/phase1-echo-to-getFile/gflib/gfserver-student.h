/*
 *  This file is for use by students to define anything they wish.  It is used by the gf server implementation
 */
#ifndef __GF_SERVER_STUDENT_H__
#define __GF_SERVER_STUDENT_H__
#define BUFSIZE 5120
#define PATH_BUFFER_SIZE 5120
#include "gf-student.h"
#include "gfserver.h"
#include <stdlib.h>
#include <stdbool.h>

// gfcontext_t has an int client_socket, which is the socket returned by accept.
struct gfcontext_t
{
    int client_socket;
};

// Modify this file to implement the interface specified in
// gfserver.h.

struct gfserver_t
{
    unsigned short port;
    int max_pending;
    gfh_error_t (*handler)(gfcontext_t **, const char *, void *);
    void *handler_arg;
};


#endif // __GF_SERVER_STUDENT_H__