#include "gfserver-student.h"

/*
 * Aborts the connection to the client associated with the input
 * gfcontext_t.
 */
void gfs_abort(gfcontext_t **ctx)
{
    close((*ctx)->client_socket);
    free(*ctx);
}

/*
 * Sends size bytes starting at the pointer data to the client
 * This function should only be called from within a callback registered
 * with gfserver_set_handler.  It returns once the data has been
 * sent.
 */
ssize_t gfs_send(gfcontext_t **ctx, const void *data, size_t len)
{
    ssize_t bytesAlreadySent = 0;
    while (bytesAlreadySent < len)
    {
        int connectionSocket = (*ctx)->client_socket;
        const void *ptr = data + bytesAlreadySent;
        int length = len - bytesAlreadySent;
        ssize_t sent = send(connectionSocket, ptr, length, 0);
        bytesAlreadySent += sent;
    }
    return bytesAlreadySent;
}

/*
 * Sends to the client the Getfile header containing the appropriate
 * status and file length for the given inputs.  This function should
 * only be called from within a callback registered gfserver_set_handler.
 */
ssize_t gfs_sendheader(gfcontext_t **ctx, gfstatus_t status, size_t file_len)
{
    // header is small
    char header[256];
    if (status == GF_OK)
    {
        // search on google for sprintf how to convert an size_t to a string in C, answer is %zu.
        snprintf(header, sizeof(header),"GETFILE OK %zu\r\n\r\n", file_len);
    }
    else if (status == GF_FILE_NOT_FOUND)
    {
        snprintf(header, sizeof(header),"GETFILE FILE_NOT_FOUND\r\n\r\n");
    }
    else if (status == GF_ERROR)
    {
        snprintf(header,sizeof(header), "GETFILE ERROR\r\n\r\n");
    }
    else if (status == GF_INVALID)
    {
        snprintf(header, sizeof(header),"GETFILE INVALID\r\n\r\n");
    }
    return gfs_send(ctx, header, strlen(header));
}

/*
 * This function must be the first one called as part of
 * setting up a server.  It returns a gfserver_t handle which should be
 * passed into all subsequent library calls of the form gfserver_*.  It
 * is not needed for the gfs_* call which are intended to be called from
 * the handler callback.
 */
gfserver_t *gfserver_create()
{
    gfserver_t *server = malloc(sizeof(gfserver_t));
    memset(server, 0, sizeof(gfserver_t));
    server->port = 10680;
    server->max_pending = 10;
    server->handler = NULL;
    server->handler_arg = NULL;
    return server;
}

/*
 * Sets the handler callback, a function that will be called for each each
 * request.  As arguments, this function receives:
 * - a gfcontext_t handle which it must pass into the gfs_* functions that
 * 	 it calls as it handles the response.
 * - the requested path
 * - the pointer specified in the gfserver_set_handlerarg option.
 */
void gfserver_set_handler(gfserver_t **gfs, gfh_error_t (*handler)(gfcontext_t **, const char *, void *))
{
    (*gfs)->handler = handler;
}

void gfserver_set_maxpending(gfserver_t **gfs, int max_npending)
{
    (*gfs)->max_pending = max_npending;
}

/*
 * Sets the port at which the server will listen for connections.
 */
void gfserver_set_port(gfserver_t **gfs, unsigned short port)
{
    (*gfs)->port = port;
}

/*
 * Sets the third argument for calls to the handler callback.
 */
void gfserver_set_handlerarg(gfserver_t **gfs, void *arg)
{
    (*gfs)->handler_arg = arg;
}

/*
 * Starts the server.  Does not return.
 */
void gfserver_serve(gfserver_t **gfs)
{
    struct sockaddr_in6 serv_addr, cli_addr;
    int welcomeSocket, connectionSocket;
    char buffer[BUFSIZE];
    socklen_t clilen;
    welcomeSocket = socket(AF_INET6, SOCK_STREAM, 0);
    memset(&serv_addr, 0, sizeof(serv_addr));
    unsigned short portno = (*gfs)->port;
    serv_addr.sin6_family = AF_INET6;
    serv_addr.sin6_port = htons(portno);
    serv_addr.sin6_addr = in6addr_any;
    int yes = 1;
    setsockopt(welcomeSocket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));
    bind(welcomeSocket, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
    int maxnpending = (*gfs)->max_pending;
    listen(welcomeSocket, maxnpending);
    clilen = sizeof(cli_addr);
    while (1)
    {
        connectionSocket = accept(welcomeSocket, (struct sockaddr *)&cli_addr, &clilen);
        memset(buffer, 0, BUFSIZE);
        gfcontext_t *ctx = malloc(sizeof(gfcontext_t));
        memset(ctx, 0, sizeof(gfcontext_t));
        ctx->client_socket = connectionSocket;
        int request_len = 0;
        while (1)
        {
            request_len += recv(connectionSocket, buffer + request_len, BUFSIZE, 0);
            if (request_len >= 4 && strcmp(buffer + request_len - 4, "\r\n\r\n") == 0)
            {
                break;
            }
        }
        char schema[MAX_REQUEST_LEN] = {0};
        char method[MAX_REQUEST_LEN] = {0};
        char path[PATH_BUFFER_SIZE] = {0};
        bool invalid_header = false;
        // sscanf(buffer, "%s %s %s\r\n\r\n", schema, method, path);
        // printf("schema: %s, method: %s, path: %s, invalid_header: %d\n", schema, method, path, invalid_header);
        // if (strcmp(schema, "GETFILE") != 0 || strcmp(method, "GET") != 0 || path[0] != '/')
        // {
        //     invalid_header = true;
        // }
        // if (strlen(path) < 4 || strcmp(path + strlen(path) - 4, "\r\n\r\n") != 0)
        // {
        //     // printf("strlen(path): %zu\n", strlen(path));
        //     // printf("path: %s\n", path + strlen(path) - 4);
        //     invalid_header = true;
        // }
        char * token = NULL;
        token = strtok(buffer, " ");
        if(token == NULL || strcmp(token, "GETFILE") != 0)
        {
            invalid_header = true;
        }
        int len = strlen(token);
        token = strtok(NULL, " ");
        if(token == NULL || strcmp(token, "GET") != 0)
        {
            invalid_header = true;
        }
        len += strlen(token) + 2;
        for(int i = 0; i < request_len - 4 - len ; i++){
            path[i] = buffer[i + len];
        }
        if(path[0] != '/')
        {
            invalid_header = true;
        }
        // for (int i = 0;;)
        // {
        //     int j = 0;
        //     while (i < request_len && buffer[i] != ' ')
        //     {
        //         schema[j] = buffer[i];
        //         i++;
        //         j++;
        //     }
        //     if (i >= request_len || strcmp(schema, "GETFILE") != 0)
        //     {
        //         invalid_header = true;
        //         break;
        //     }
        //     i++;
        //     j = 0;
        //     while (i < request_len && buffer[i] != ' ')
        //     {
        //         method[j] = buffer[i];
        //         i++;
        //         j++;
        //     }
        //     if (i >= request_len || strcmp(method, "GET") != 0)
        //     {
        //         invalid_header = true;
        //         break;
        //     }
        //     i++;
        //     j = 0;
        //     while ((i + 3) < request_len && (buffer[i] != '\r' || buffer[i + 1] != '\n' || buffer[i + 2] != '\r' || buffer[i + 3] != '\n'))
        //     {
        //         path[j] = buffer[i];
        //         i++;
        //         j++;
        //     }
        //     if ((i + 3) >= request_len || path[0] != '/')
        //     {
        //         invalid_header = true;
        //         break;
        //     }
        //     break;
        // }

        printf("schema: %s, method: %s, path: %s, pathlen: %ld, invalid_header: %d\n", schema, method, path, strlen(path), invalid_header);

        if (invalid_header)
        {
            gfs_sendheader(&ctx, GF_INVALID, 0);
            gfs_abort(&ctx);
            continue;
        }
        // find handler pointer and call it
        (*(*gfs)->handler)(&ctx, path, (*gfs)->handler_arg);
    }
    close(welcomeSocket);
}
