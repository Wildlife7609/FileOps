#include <stdlib.h>
#include <errno.h>
#include <getopt.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <stdio.h>

#include <string.h>
#include <unistd.h>

#define BUFSIZE 512

#define USAGE                                            \
  "usage:\n"                                             \
  "  transferserver [options]\n"                         \
  "options:\n"                                           \
  "  -h                  Show this help message\n"       \
  "  -f                  Filename (Default: 6200.txt)\n" \
  "  -p                  Port (Default: 10623)\n"

/* OPTIONS DESCRIPTOR ====================================================== */
static struct option gLongOptions[] = {
    {"help", no_argument, NULL, 'h'},
    {"port", required_argument, NULL, 'p'},
    {"filename", required_argument, NULL, 'f'},
    {NULL, 0, NULL, 0}};

int main(int argc, char **argv)
{
  char *filename = "6200.txt"; // file to transfer
  int portno = 10623;          // port to listen on
  int option_char;

  setbuf(stdout, NULL); // disable buffering

  // Parse and set command line arguments
  while ((option_char =
              getopt_long(argc, argv, "hf:xp:", gLongOptions, NULL)) != -1)
  {
    switch (option_char)
    {
    case 'h': // help
      fprintf(stdout, "%s", USAGE);
      exit(0);
      break;
    case 'p': // listen-port
      portno = atoi(optarg);
      break;
    case 'f': // file to transfer
      filename = optarg;
      break;
    default:
      fprintf(stderr, "%s", USAGE);
      exit(1);
    }
  }

  if ((portno < 1025) || (portno > 65535))
  {
    fprintf(stderr, "%s @ %d: invalid port number (%d)\n", __FILE__, __LINE__,
            portno);
    exit(1);
  }

  if (NULL == filename)
  {
    fprintf(stderr, "%s @ %d: invalid filename\n", __FILE__, __LINE__);
    exit(1);
  }

  /* Socket Code Here */
  int maxnpending = 5;
  struct sockaddr_in6 serv_addr;
  struct sockaddr cli_addr;
  int welcomeSocket, connectionSocket;
  char buffer[BUFSIZE];
  socklen_t clilen;
  welcomeSocket = socket(AF_INET6, SOCK_STREAM, 0);
  memset(&serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin6_family = AF_INET6;
  serv_addr.sin6_port = htons(portno);
  serv_addr.sin6_addr = in6addr_any;
  int yes = 1;
  setsockopt(welcomeSocket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));
  bind(welcomeSocket, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
  listen(welcomeSocket, maxnpending);
  clilen = sizeof(cli_addr);
  while (1)
  {
    connectionSocket = accept(welcomeSocket, (struct sockaddr *)&cli_addr, &clilen);
    memset(buffer, 0, BUFSIZE);
    FILE *fp = fopen(filename, "r");
    int read;
    if (fp == NULL)
    {
      fprintf(stderr, "Error opening file: %s\n", strerror(errno));
      exit(1);
    }
    while (1)
    {
      read = fread(buffer, 1, BUFSIZE, fp);
      if (read == 0)
      {
        break;
      }
      send(connectionSocket, buffer, read, 0);
    }
    close(connectionSocket);
  }
  close(welcomeSocket);
  return 0;
}
